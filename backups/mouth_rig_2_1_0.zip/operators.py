import bpy
from mathutils import Vector, Matrix
from . import rig_builder, widgets

MOUTHRIG_ARMATURE_KEY = "mouthrig_armature_name"
LEGACY_WIDGET_COLLECTION_KEY = "mouthrig_widget_collection"

# Anchors that the user can grab in the viewport. Mid-arc points are detected
# from the loop and used internally for tangent orientation only.
_MIRROR_MAP = {
    rig_builder.CORNER_L: rig_builder.CORNER_R,
    rig_builder.CORNER_R: rig_builder.CORNER_L,
}

_MIRROR_MAP_FULL = {
    rig_builder.CORNER_L: rig_builder.CORNER_R,
    rig_builder.CORNER_R: rig_builder.CORNER_L,
    rig_builder.TOP_L_MID: rig_builder.TOP_R_MID,
    rig_builder.TOP_R_MID: rig_builder.TOP_L_MID,
    rig_builder.BOT_L_MID: rig_builder.BOT_R_MID,
    rig_builder.BOT_R_MID: rig_builder.BOT_L_MID,
}


def _detect_anchor_data(mesh_obj):
    raw_verts, follows_selected_edges = rig_builder.get_selected_loop_verts_with_order(mesh_obj)
    ordered_verts = raw_verts if follows_selected_edges else rig_builder.order_loop_verts(raw_verts)
    return rig_builder.detect_loop_landmarks(ordered_verts)


def _mirror_rotation(rotation, horizontal_axis):
    rot_mat = rotation.to_matrix()
    columns = [
        rig_builder.reflect_across_symmetry_plane(rot_mat @ Vector((1.0, 0.0, 0.0)), None, horizontal_axis, False),
        rig_builder.reflect_across_symmetry_plane(rot_mat @ Vector((0.0, 1.0, 0.0)), None, horizontal_axis, False),
        rig_builder.reflect_across_symmetry_plane(rot_mat @ Vector((0.0, 0.0, 1.0)), None, horizontal_axis, False),
    ]
    columns[0].negate()
    mirrored = Matrix((
        (columns[0].x, columns[1].x, columns[2].x),
        (columns[0].y, columns[1].y, columns[2].y),
        (columns[0].z, columns[1].z, columns[2].z),
    )).to_quaternion()
    mirrored.normalize()
    return mirrored


def _remove_armature_object(arm_obj):
    if not arm_obj:
        return
    arm_data = arm_obj.data
    bpy.data.objects.remove(arm_obj, do_unlink=True)
    if arm_data and arm_data.users == 0:
        bpy.data.armatures.remove(arm_data)


def _remove_collection(collection_name):
    if not collection_name:
        return
    coll = bpy.data.collections.get(collection_name)
    if not coll:
        return
    for obj in list(coll.objects):
        mesh_data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh_data and getattr(mesh_data, "users", 0) == 0:
            bpy.data.meshes.remove(mesh_data)
    bpy.data.collections.remove(coll)


def _clear_mesh_rig(mesh_obj):
    armatures_to_remove = []

    stored_arm_name = mesh_obj.get(MOUTHRIG_ARMATURE_KEY)
    if stored_arm_name:
        arm_obj = bpy.data.objects.get(stored_arm_name)
        if arm_obj:
            armatures_to_remove.append(arm_obj)

    for mod in list(mesh_obj.modifiers):
        if mod.type != 'ARMATURE':
            continue
        arm_obj = mod.object
        owns_mesh = arm_obj and arm_obj.get("mouthrig_owner_mesh") == mesh_obj.name
        stored_match = arm_obj and stored_arm_name and arm_obj.name == stored_arm_name
        if owns_mesh or stored_match:
            mesh_obj.modifiers.remove(mod)
            if arm_obj and arm_obj not in armatures_to_remove:
                armatures_to_remove.append(arm_obj)

    legacy_collection = mesh_obj.get(LEGACY_WIDGET_COLLECTION_KEY)
    owns_rig_data = bool(stored_arm_name or armatures_to_remove or legacy_collection)
    if owns_rig_data:
        for name in rig_builder.DEFORM_GROUP_NAMES:
            vg = mesh_obj.vertex_groups.get(name)
            if vg:
                mesh_obj.vertex_groups.remove(vg)

    if legacy_collection:
        _remove_collection(legacy_collection)
    for arm_obj in armatures_to_remove:
        _remove_collection(f"WGTS_{arm_obj.name}")

    if mesh_obj.parent in armatures_to_remove:
        world_matrix = mesh_obj.matrix_world.copy()
        mesh_obj.parent = None
        mesh_obj.matrix_world = world_matrix

    for arm_obj in armatures_to_remove:
        _remove_armature_object(arm_obj)

    for key in (MOUTHRIG_ARMATURE_KEY, LEGACY_WIDGET_COLLECTION_KEY):
        if key in mesh_obj:
            del mesh_obj[key]


def _mesh_has_mouthrig(mesh_obj):
    if mesh_obj is None or mesh_obj.type != 'MESH':
        return False
    if mesh_obj.get(MOUTHRIG_ARMATURE_KEY):
        return True
    return any(
        mod.type == 'ARMATURE'
        and mod.object is not None
        and mod.object.get("mouthrig_owner_mesh") == mesh_obj.name
        for mod in mesh_obj.modifiers
    )


def _preview_mesh(context):
    mesh_obj = widgets.load_preview_mesh(context.scene)
    return mesh_obj if mesh_obj is not None and mesh_obj.type == 'MESH' else None


def _clear_target_mesh(context):
    obj = context.active_object
    if obj is not None and obj.type == 'ARMATURE':
        owner_name = obj.get("mouthrig_owner_mesh")
        owner = bpy.data.objects.get(owner_name) if owner_name else None
        if owner is None:
            owner = next(
                (
                    candidate
                    for candidate in bpy.data.objects
                    if candidate.type == 'MESH'
                    and candidate.get(MOUTHRIG_ARMATURE_KEY) == obj.name
                ),
                None,
            )
        if _mesh_has_mouthrig(owner):
            return owner

    if obj is not None and obj.type == 'MESH' and _mesh_has_mouthrig(obj):
        return obj

    return _preview_mesh(context)


def _find_mouthrig_armature(context):
    obj = context.active_object
    if obj is not None and obj.type == 'ARMATURE' and obj.get("mouthrig_owner_mesh"):
        return obj

    mesh_obj = _clear_target_mesh(context)
    if mesh_obj:
        stored_arm_name = mesh_obj.get(MOUTHRIG_ARMATURE_KEY)
        if stored_arm_name:
            arm_obj = bpy.data.objects.get(stored_arm_name)
            if arm_obj:
                return arm_obj
        for mod in mesh_obj.modifiers:
            if (
                mod.type == 'ARMATURE'
                and mod.object
                and mod.object.get("mouthrig_owner_mesh") == mesh_obj.name
            ):
                return mod.object
    return None


def _validate_build_target(mesh_obj):
    stored_arm_name = mesh_obj.get(MOUTHRIG_ARMATURE_KEY)
    foreign_modifiers = [
        mod.name
        for mod in mesh_obj.modifiers
        if mod.type == 'ARMATURE'
        and (
            mod.object is None
            or (
                mod.object.get("mouthrig_owner_mesh") != mesh_obj.name
                and mod.object.name != stored_arm_name
            )
        )
    ]
    if foreign_modifiers:
        names = ", ".join(foreign_modifiers)
        raise ValueError(
            "The mesh already uses another Armature modifier "
            f"({names}). Duplicate the mesh or remove that modifier before generating this separate rig."
        )

    if (
        mesh_obj.parent is not None
        and mesh_obj.parent.type == 'ARMATURE'
        and mesh_obj.parent.get("mouthrig_owner_mesh") != mesh_obj.name
        and mesh_obj.parent.name != stored_arm_name
    ):
        raise ValueError(
            "The mesh is already parented to another armature. Duplicate or unparent it before generating this rig."
        )


def _validate_vertex_group_conflicts(mesh_obj):
    conflicts = [name for name in rig_builder.DEFORM_GROUP_NAMES if mesh_obj.vertex_groups.get(name)]
    if conflicts:
        shown = ", ".join(conflicts[:4])
        suffix = "..." if len(conflicts) > 4 else ""
        raise ValueError(
            "Existing vertex groups would be overwritten: "
            f"{shown}{suffix}. Rename those groups before generating the rig."
        )


def apply_bone_visibility(context):
    arm_obj = _find_mouthrig_armature(context)
    if not arm_obj:
        return

    arm_obj.show_in_front = True
    arm_obj.data.display_type = 'BBONE'

    scene = context.scene
    show_def = getattr(scene, "mouthrig_show_def_bones", True)
    show_ctrl = getattr(scene, "mouthrig_show_ctrl_bones", True)
    show_jaw = getattr(scene, "mouthrig_show_jaw_bone", True)
    show_head = getattr(scene, "mouthrig_show_head_bone", False)

    ctrl_set = set(rig_builder.MASTER_CTRL_NAMES) | set(rig_builder.SUB_CTRL_NAMES)
    def_set = set(rig_builder.DEF_BONE_NAMES)

    for bone in arm_obj.data.bones:
        if bone.name == rig_builder.HEAD_BONE_NAME:
            bone.hide = not show_head
        elif bone.name == rig_builder.JAW_BONE_NAME:
            bone.hide = not show_jaw
        elif bone.name in def_set:
            bone.hide = not show_def
        elif bone.name in ctrl_set:
            bone.hide = not show_ctrl


class MOUTHRIG_OT_preview(bpy.types.Operator):
    bl_idname = "mouthrig.preview"
    bl_label = "Preview Controls"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Detect the 4 mouth anchors and create preview circles plus placement empties"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        mesh_obj = context.active_object

        try:
            anchor_positions, anchor_normals = _detect_anchor_data(mesh_obj)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')

        scene = context.scene
        radius = scene.mouthrig_widget_radius
        align = scene.mouthrig_align_to_normal
        offset = scene.mouthrig_surface_offset

        y_axis = Vector((0.0, 1.0, 0.0))
        if align:
            rotations = {
                name: y_axis.rotation_difference(anchor_normals[name].normalized())
                for name in anchor_normals
            }
        else:
            rotations = {}

        widgets.save_preview_data(scene, anchor_positions, anchor_normals)
        widgets.save_preview_mesh(scene, mesh_obj)
        widgets.save_rotations(scene, rotations)
        widgets.create_preview_widgets(
            anchor_positions,
            radius,
            normals=anchor_normals,
            rotations=rotations or None,
            offset=offset,
        )

        self.report(
            {'INFO'},
            "4 anchor previews + Head/Jaw/Jaw-Control empties created. Place them, then click Build.",
        )
        return {'FINISHED'}


def _parent_with_auto_weights(mesh_obj, arm_obj):
    """Parent the mesh to the armature using Blender bone-heat weights.

    Replaces the previous custom proximity weighter. parent_set creates the
    Armature modifier and vertex groups for every deform bone.
    """
    if bpy.context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    for obj in bpy.context.selected_objects:
        obj.select_set(False)

    mesh_obj.select_set(True)
    arm_obj.select_set(True)
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')


def _verify_auto_weights(mesh_obj, arm_obj):
    has_modifier = any(
        mod.type == 'ARMATURE' and mod.object == arm_obj
        for mod in mesh_obj.modifiers
    )
    if not has_modifier:
        raise RuntimeError("Blender did not create the expected Armature modifier.")

    missing = []
    empty = []
    for name in rig_builder.DEFORM_GROUP_NAMES:
        group = mesh_obj.vertex_groups.get(name)
        if group is None:
            missing.append(name)
            continue
        if not any(
            assignment.group == group.index
            for vertex in mesh_obj.data.vertices
            for assignment in vertex.groups
        ):
            empty.append(name)

    if missing or empty:
        details = []
        if missing:
            details.append("missing groups: " + ", ".join(missing))
        if empty:
            details.append("empty groups: " + ", ".join(empty))
        raise RuntimeError("Automatic weighting was incomplete (" + "; ".join(details) + ").")


def _rollback_failed_build(mesh_obj, arm_obj):
    if bpy.context.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except RuntimeError:
            pass

    if arm_obj is not None:
        if mesh_obj.parent == arm_obj:
            world_matrix = mesh_obj.matrix_world.copy()
            mesh_obj.parent = None
            mesh_obj.matrix_world = world_matrix

        for mod in list(mesh_obj.modifiers):
            if mod.type == 'ARMATURE' and mod.object == arm_obj:
                mesh_obj.modifiers.remove(mod)

        for name in rig_builder.DEFORM_GROUP_NAMES:
            vg = mesh_obj.vertex_groups.get(name)
            if vg:
                mesh_obj.vertex_groups.remove(vg)

        _remove_armature_object(arm_obj)

    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    mesh_obj.select_set(True)
    bpy.context.view_layer.objects.active = mesh_obj


class MOUTHRIG_OT_build(bpy.types.Operator):
    bl_idname = "mouthrig.build"
    bl_label = "Generate Mouth Rig"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        mesh_obj = _preview_mesh(context)
        positions, _normals = widgets.load_preview_data(context.scene)
        return mesh_obj is not None and positions is not None

    def execute(self, context):
        mesh_obj = _preview_mesh(context)
        if mesh_obj is None:
            self.report({'ERROR'}, "No preview mesh found. Display controls first.")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        anchor_positions, anchor_normals = widgets.sync_preview_positions_from_viewport(context.scene)
        if anchor_positions is None:
            self.report({'ERROR'}, "No anchors found. Display controls first.")
            return {'CANCELLED'}

        head_origin = widgets.get_head_origin_location()
        jaw_origin = widgets.get_jaw_empty_location()
        jaw_control = widgets.get_jaw_control_location()
        if head_origin is None or jaw_origin is None or jaw_control is None:
            self.report({'ERROR'}, "Missing placement empty (Head/Jaw/Jaw-Control). Display controls first.")
            return {'CANCELLED'}

        widgets.sync_rotations_from_viewport(context.scene)

        try:
            _validate_build_target(mesh_obj)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        _clear_mesh_rig(mesh_obj)

        try:
            _validate_vertex_group_conflicts(mesh_obj)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        scene = context.scene
        offset = scene.mouthrig_surface_offset
        bbone_segments = scene.mouthrig_bbone_segments
        corner_jaw_follow = scene.mouthrig_corner_jaw_follow
        bottom_jaw_follow = scene.mouthrig_bottom_jaw_follow

        arm_obj = None
        existing_armature_names = {
            obj.name for obj in bpy.data.objects if obj.type == 'ARMATURE'
        }
        try:
            arm_obj = rig_builder.build_armature(
                anchor_positions,
                mesh_obj,
                normals=anchor_normals,
                offset=offset,
                head_origin=head_origin,
                jaw_origin=jaw_origin,
                jaw_control=jaw_control,
                bbone_segments=bbone_segments,
                corner_jaw_follow=corner_jaw_follow,
                bottom_jaw_follow=bottom_jaw_follow,
            )
            _parent_with_auto_weights(mesh_obj, arm_obj)
            _verify_auto_weights(mesh_obj, arm_obj)
        except Exception as exc:
            if arm_obj is None:
                arm_obj = next(
                    (
                        obj
                        for obj in bpy.data.objects
                        if obj.type == 'ARMATURE'
                        and obj.name not in existing_armature_names
                        and obj.get("mouthrig_owner_mesh") == mesh_obj.name
                    ),
                    None,
                )
            _rollback_failed_build(mesh_obj, arm_obj)
            self.report({'ERROR'}, f"Could not generate the rig: {exc}")
            return {'CANCELLED'}

        mesh_obj[MOUTHRIG_ARMATURE_KEY] = arm_obj.name
        apply_bone_visibility(context)
        widgets.clear_preview_widgets()
        widgets.clear_preview_state(context.scene)

        self.report({'INFO'}, "Mouth rig generated successfully.")
        return {'FINISHED'}


class MOUTHRIG_OT_clear(bpy.types.Operator):
    bl_idname = "mouthrig.clear"
    bl_label = "Clear Mouth Rig"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _clear_target_mesh(context) is not None

    def execute(self, context):
        mesh_obj = _clear_target_mesh(context)
        if mesh_obj is None:
            self.report({'WARNING'}, "No Mouth Rig or preview found to clear.")
            return {'CANCELLED'}

        preview_mesh = _preview_mesh(context)
        _clear_mesh_rig(mesh_obj)

        if preview_mesh == mesh_obj:
            widgets.clear_preview_widgets()
            widgets.clear_preview_state(context.scene)

        self.report({'INFO'}, "Mouth rig cleared.")
        return {'FINISHED'}


class MOUTHRIG_OT_symmetrize(bpy.types.Operator):
    bl_idname = "mouthrig.symmetrize"
    bl_label = "Symmetrize Controls"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = (
        "Mirror selected preview anchors to their opposite side. "
        "Select PREVIEW_corner_L or PREVIEW_corner_R, then click."
    )

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'OBJECT'
            and any(
                obj.name.startswith("PREVIEW_") and obj.name[len("PREVIEW_"):] in _MIRROR_MAP
                for obj in context.selected_objects
            )
        )

    def execute(self, context):
        scene = context.scene
        positions, normals = widgets.load_preview_data(scene)
        if positions is None:
            self.report({'WARNING'}, "No preview - run Preview first.")
            return {'CANCELLED'}

        offset = scene.mouthrig_surface_offset
        center, horizontal_axis = rig_builder.compute_symmetry_plane(positions)

        selected = {
            obj.name[len("PREVIEW_"):]: obj
            for obj in context.selected_objects
            if obj.name.startswith("PREVIEW_")
            and obj.name[len("PREVIEW_"):] in _MIRROR_MAP
        }

        if rig_builder.CORNER_L in selected and rig_builder.CORNER_R in selected:
            self.report({'ERROR'}, "Select only one corner anchor as the symmetry source.")
            return {'CANCELLED'}

        rotations = widgets.load_rotations(scene)
        mirrored = 0

        for ctrl_name, obj in selected.items():
            src_nrm = normals.get(ctrl_name)
            displayed_pos = obj.location.copy()
            if src_nrm is not None and offset != 0.0:
                base_pos = rig_builder.apply_surface_offset(displayed_pos, src_nrm, -offset)
            else:
                base_pos = displayed_pos
            positions[ctrl_name] = base_pos

            if obj.rotation_mode == 'QUATERNION':
                src_rot = obj.rotation_quaternion.copy()
            else:
                src_rot = obj.rotation_euler.to_quaternion()
            rotations[ctrl_name] = src_rot

            mirror_name = _MIRROR_MAP[ctrl_name]
            positions[mirror_name] = rig_builder.reflect_across_symmetry_plane(
                base_pos, center, horizontal_axis, is_point=True,
            )
            if src_nrm is not None:
                normals[mirror_name] = rig_builder.reflect_across_symmetry_plane(
                    src_nrm, center, horizontal_axis, is_point=False,
                )
            rotations[mirror_name] = _mirror_rotation(src_rot, horizontal_axis)
            mirrored += 1

        # Mirror the corresponding mid-arc points for whichever side the user
        # mirrored from, so build-time tangents stay consistent.
        if rig_builder.CORNER_L in selected:
            mid_pairs = ((rig_builder.TOP_L_MID, rig_builder.TOP_R_MID),
                         (rig_builder.BOT_L_MID, rig_builder.BOT_R_MID))
        elif rig_builder.CORNER_R in selected:
            mid_pairs = ((rig_builder.TOP_R_MID, rig_builder.TOP_L_MID),
                         (rig_builder.BOT_R_MID, rig_builder.BOT_L_MID))
        else:
            mid_pairs = ()

        for src_mid, dst_mid in mid_pairs:
            if src_mid not in positions:
                continue
            positions[dst_mid] = rig_builder.reflect_across_symmetry_plane(
                positions[src_mid], center, horizontal_axis, is_point=True,
            )
            src_nrm = normals.get(src_mid)
            if src_nrm is not None:
                normals[dst_mid] = rig_builder.reflect_across_symmetry_plane(
                    src_nrm, center, horizontal_axis, is_point=False,
                )

        widgets.save_preview_data(scene, positions, normals)
        widgets.save_rotations(scene, rotations)
        widgets.create_preview_widgets(
            positions,
            radius=scene.mouthrig_widget_radius,
            normals=normals,
            rotations=rotations or None,
            offset=offset,
        )

        self.report({'INFO'}, f"Symmetrized {mirrored} anchor(s).")
        return {'FINISHED'}


class MOUTHRIG_OT_apply_visibility(bpy.types.Operator):
    bl_idname = "mouthrig.apply_visibility"
    bl_label = "Apply Bone Visibility"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _find_mouthrig_armature(context) is not None

    def execute(self, context):
        apply_bone_visibility(context)
        return {'FINISHED'}


_classes = (
    MOUTHRIG_OT_preview,
    MOUTHRIG_OT_build,
    MOUTHRIG_OT_clear,
    MOUTHRIG_OT_symmetrize,
    MOUTHRIG_OT_apply_visibility,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
