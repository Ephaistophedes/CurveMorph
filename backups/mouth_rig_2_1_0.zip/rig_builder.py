import bpy
import bmesh
import math
from mathutils import Vector

# ---------------------------------------------------------------------------
# Anchor + bone naming
# ---------------------------------------------------------------------------

# 4 main anchor positions detected from the selected mouth loop.
TOP_C = "top_C"
BOT_C = "bot_C"
CORNER_L = "corner_L"
CORNER_R = "corner_R"
ANCHOR_NAMES = [TOP_C, BOT_C, CORNER_L, CORNER_R]

# 4 mid-arc points used for tangent orientation of the corner sub-CTRLs.
TOP_L_MID = "top_L_mid"
TOP_R_MID = "top_R_mid"
BOT_L_MID = "bot_L_mid"
BOT_R_MID = "bot_R_mid"
LANDMARK_NAMES = ANCHOR_NAMES + [TOP_L_MID, TOP_R_MID, BOT_L_MID, BOT_R_MID]

# Root + jaw deform bones.
HEAD_BONE_NAME = "Head"
JAW_BONE_NAME = "Jaw"

# Deform strands (one per lip quadrant).
DEF_TOP_R = "DEF_Top_R"
DEF_TOP_L = "DEF_Top_L"
DEF_BOTTOM_R = "DEF_Bottom_R"
DEF_BOTTOM_L = "DEF_Bottom_L"
DEF_BONE_NAMES = [DEF_TOP_R, DEF_TOP_L, DEF_BOTTOM_R, DEF_BOTTOM_L]
DEFORM_GROUP_NAMES = [HEAD_BONE_NAME, JAW_BONE_NAME] + DEF_BONE_NAMES

# Master CTRL bones.
MOUTH_CENTER_TOP_CTRL = "Mouth_Center_Top_CTRL"
MOUTH_CENTER_BOTTOM_CTRL = "Mouth_Center_Bottom_CTRL"
CORNER_CTRL_R = "Corner_CTRL_R"
CORNER_CTRL_L = "Corner_CTRL_L"
MASTER_CTRL_NAMES = [
    MOUTH_CENTER_TOP_CTRL,
    MOUTH_CENTER_BOTTOM_CTRL,
    CORNER_CTRL_R,
    CORNER_CTRL_L,
]

# Sub CTRL bones (StretchTo targets / strand hooks).
CENTER_TOP_CTRL_R = "Center_Top_CTRL_R"
CENTER_TOP_CTRL_L = "Center_Top_CTRL_L"
CENTER_BOTTOM_CTRL_R = "Center_Bottom_CTRL_R"
CENTER_BOTTOM_CTRL_L = "Center_Bottom_CTRL_L"
CORNER_TOP_CTRL_R = "Corner_Top_CTRL_R"
CORNER_TOP_CTRL_L = "Corner_Top_CTRL_L"
CORNER_BOTTOM_CTRL_R = "Corner_Bottom_CTRL_R"
CORNER_BOTTOM_CTRL_L = "Corner_Bottom_CTRL_L"
SUB_CTRL_NAMES = [
    CENTER_TOP_CTRL_R, CENTER_TOP_CTRL_L,
    CENTER_BOTTOM_CTRL_R, CENTER_BOTTOM_CTRL_L,
    CORNER_TOP_CTRL_R, CORNER_TOP_CTRL_L,
    CORNER_BOTTOM_CTRL_R, CORNER_BOTTOM_CTRL_L,
]

# Aggregate list used by cleanup helpers.
ALL_BONE_NAMES = (
    DEFORM_GROUP_NAMES
    + MASTER_CTRL_NAMES
    + SUB_CTRL_NAMES
)


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def apply_surface_offset(position, normal, offset):
    """Return a position moved along the full normalized surface normal."""
    if offset == 0.0 or normal is None:
        return position.copy()
    return position + (normal.normalized() * offset)


def _normalized(vec):
    if vec.length_squared < 1e-12:
        return None
    result = vec.copy()
    result.normalize()
    return result


def _compute_loop_basis(positions, normals=None):
    """Return centroid plus projected horizontal and vertical axes for the loop."""
    count = len(positions)
    centroid = Vector((0.0, 0.0, 0.0))
    for pos in positions:
        centroid += pos
    centroid /= count

    surface_normal = None
    if normals:
        normal_sum = sum(normals, Vector((0.0, 0.0, 0.0)))
        surface_normal = _normalized(normal_sum)

    if surface_normal is not None:
        vertical = Vector((0.0, 0.0, 1.0))
        vertical -= surface_normal * vertical.dot(surface_normal)
        vertical = _normalized(vertical)
        if vertical is None:
            vertical = Vector((0.0, 1.0, 0.0))
            vertical -= surface_normal * vertical.dot(surface_normal)
            vertical = _normalized(vertical) or Vector((1.0, 0.0, 0.0))

        horizontal = _normalized(surface_normal.cross(vertical))
        if horizontal is not None:
            right_ref = Vector((1.0, 0.0, 0.0))
            right_ref -= surface_normal * right_ref.dot(surface_normal)
            right_ref = _normalized(right_ref)
            if right_ref is None:
                right_ref = Vector((0.0, 1.0, 0.0))
                right_ref -= surface_normal * right_ref.dot(surface_normal)
                right_ref = _normalized(right_ref)
            if right_ref is not None and horizontal.dot(right_ref) < 0.0:
                horizontal.negate()
            return centroid, horizontal, vertical

    var = [0.0, 0.0, 0.0]
    for pos in positions:
        delta = pos - centroid
        var[0] += delta.x * delta.x
        var[1] += delta.y * delta.y
        var[2] += delta.z * delta.z

    min_axis = var.index(min(var))
    if min_axis == 0:
        horizontal = Vector((0.0, 1.0, 0.0))
        vertical = Vector((0.0, 0.0, 1.0))
    elif min_axis == 1:
        horizontal = Vector((1.0, 0.0, 0.0))
        vertical = Vector((0.0, 0.0, 1.0))
    else:
        horizontal = Vector((1.0, 0.0, 0.0))
        vertical = Vector((0.0, 1.0, 0.0))

    return centroid, horizontal, vertical


def _order_indices_from_selected_edges(selected_indices, selected_edges):
    selected = set(selected_indices)
    adjacency = {index: [] for index in selected_indices}

    for idx_a, idx_b in selected_edges:
        if idx_a not in selected or idx_b not in selected:
            continue
        adjacency[idx_a].append(idx_b)
        adjacency[idx_b].append(idx_a)

    if not adjacency:
        return None

    closed_loop = all(len(neighbors) == 2 for neighbors in adjacency.values())
    if not closed_loop:
        return None

    start = min(selected_indices)
    ordered = [start]
    visited = {start}
    previous = None
    current = start

    while True:
        next_candidates = [index for index in adjacency[current] if index != previous]
        if not next_candidates:
            break

        next_index = next_candidates[0]
        if next_index == start:
            return ordered if len(ordered) == len(selected_indices) else None
        if next_index in visited:
            return None

        ordered.append(next_index)
        visited.add(next_index)
        previous, current = current, next_index

        if len(ordered) == len(selected_indices):
            return ordered

    return None


def compute_symmetry_plane(anchor_positions):
    """Return a center and left-right axis for reflecting anchors in world space."""
    left = anchor_positions.get(CORNER_L)
    right = anchor_positions.get(CORNER_R)

    if left is not None and right is not None and (right - left).length_squared > 1e-12:
        return (left + right) / 2.0, (right - left).normalized()

    positions = list(anchor_positions.values())
    center, horizontal, _vertical = _compute_loop_basis(positions)
    return center, horizontal.normalized()


def reflect_across_symmetry_plane(value, center, horizontal_axis, is_point=True):
    """Reflect a point or direction across the mouth midline plane."""
    delta = value - center if is_point else value
    reflected = value - (horizontal_axis * (2.0 * delta.dot(horizontal_axis)))
    return reflected


def get_selected_loop_verts(mesh_obj):
    """Read selected verts from the active mesh in Edit Mode."""
    selected, _follows_selected_edges = get_selected_loop_verts_with_order(mesh_obj)
    return selected


def get_selected_loop_verts_with_order(mesh_obj):
    """Read selected verts and preserve selected-edge order when available."""
    bm = bmesh.from_edit_mesh(mesh_obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    world_mat = mesh_obj.matrix_world
    normal_mat = world_mat.to_3x3().inverted().transposed()
    selected_verts = [v for v in bm.verts if v.select]

    if len(selected_verts) < 8:
        raise ValueError(
            f"Select at least 8 vertices on the mouth edge loop (got {len(selected_verts)})."
        )

    selected_by_index = {
        v.index: (v.index, world_mat @ v.co.copy(), (normal_mat @ v.normal).normalized())
        for v in selected_verts
    }
    selected_edges = [
        (edge.verts[0].index, edge.verts[1].index)
        for edge in bm.edges
        if (edge.select or (edge.verts[0].select and edge.verts[1].select))
        and edge.verts[0].select
        and edge.verts[1].select
    ]
    ordered_indices = _order_indices_from_selected_edges(list(selected_by_index.keys()), selected_edges)

    if ordered_indices is not None:
        return [selected_by_index[index] for index in ordered_indices], True

    raise ValueError(
        "Select one connected, closed mouth edge loop. The selection cannot be open, branched, or contain faces inside it."
    )


def order_loop_verts(vert_data):
    """Sort verts by angle around their centroid in a best-fit projected plane."""
    positions = [item[1] for item in vert_data]
    indices = [item[0] for item in vert_data]
    normals = [item[2] for item in vert_data]
    centroid, horizontal, vertical = _compute_loop_basis(positions, normals)

    def angle_key(index):
        delta = positions[index] - centroid
        return math.atan2(vertical.dot(delta), horizontal.dot(delta))

    sorted_order = sorted(range(len(positions)), key=angle_key)
    return [(indices[i], positions[i], normals[i]) for i in sorted_order]


def _arc_mid_by_length(positions, idx_a, idx_b, count):
    """Return the loop index roughly halfway along the shorter arc between idx_a and idx_b."""
    steps_fwd = (idx_b - idx_a) % count
    steps_bwd = count - steps_fwd

    def walk(start, steps, sign):
        lengths = [
            (positions[(start + (k + 1) * sign) % count] - positions[(start + k * sign) % count]).length
            for k in range(steps)
        ]
        half = sum(lengths) / 2.0
        accum = 0.0
        for k, seg_len in enumerate(lengths):
            accum += seg_len
            if accum >= half:
                return (start + (k + 1) * sign) % count
        return idx_b

    fwd_len = sum(
        (positions[(idx_a + k + 1) % count] - positions[(idx_a + k) % count]).length
        for k in range(steps_fwd)
    )
    bwd_len = sum(
        (positions[(idx_a - k - 1) % count] - positions[(idx_a - k) % count]).length
        for k in range(steps_bwd)
    )
    return walk(idx_a, steps_fwd, 1) if fwd_len <= bwd_len else walk(idx_a, steps_bwd, -1)


def _loop_path_indices(idx_a, idx_b, count, direction):
    steps = (idx_b - idx_a) % count if direction > 0 else (idx_a - idx_b) % count
    return [(idx_a + (step * direction)) % count for step in range(steps + 1)]


def detect_loop_landmarks(ordered_verts):
    """Detect the 4 main anchors plus 4 mid-arc points on the selected loop.

    Returns (positions, normals) keyed by LANDMARK_NAMES.
    """
    positions = [item[1] for item in ordered_verts]
    normals = [item[2] for item in ordered_verts]
    count = len(positions)
    centroid, horizontal, vertical = _compute_loop_basis(positions, normals)

    def projected_coords(index):
        delta = positions[index] - centroid
        return horizontal.dot(delta), vertical.dot(delta)

    idx_left = min(range(count), key=lambda i: projected_coords(i)[0])
    idx_right = max(range(count), key=lambda i: projected_coords(i)[0])

    arc_forward = _loop_path_indices(idx_left, idx_right, count, 1)
    arc_backward = _loop_path_indices(idx_left, idx_right, count, -1)
    avg_v_forward = sum(projected_coords(i)[1] for i in arc_forward) / len(arc_forward)
    avg_v_backward = sum(projected_coords(i)[1] for i in arc_backward) / len(arc_backward)
    top_arc, bot_arc = (arc_forward, arc_backward) if avg_v_forward >= avg_v_backward else (arc_backward, arc_forward)

    idx_top = max(top_arc, key=lambda i: projected_coords(i)[1])
    idx_bot = min(bot_arc, key=lambda i: projected_coords(i)[1])

    index_map = {
        TOP_C: idx_top,
        BOT_C: idx_bot,
        CORNER_L: idx_left,
        CORNER_R: idx_right,
        TOP_L_MID: _arc_mid_by_length(positions, idx_top, idx_left, count),
        TOP_R_MID: _arc_mid_by_length(positions, idx_top, idx_right, count),
        BOT_L_MID: _arc_mid_by_length(positions, idx_bot, idx_left, count),
        BOT_R_MID: _arc_mid_by_length(positions, idx_bot, idx_right, count),
    }
    positions_out = {name: positions[index] for name, index in index_map.items()}
    normals_out = {name: normals[index] for name, index in index_map.items()}
    return positions_out, normals_out


# Back-compat alias.
detect_4_anchors = detect_loop_landmarks


# ---------------------------------------------------------------------------
# Build helpers
# ---------------------------------------------------------------------------

def _compute_axes(anchors, normals=None):
    """Return (horizontal_to_R, vertical_up, forward_out) unit vectors.

    horizontal_to_R: corner_L to corner_R direction.
    vertical_up:    bot_C to top_C direction (orthonormalized to horizontal).
    forward_out:    horizontal cross vertical, pointing away from the surface.
    """
    horizontal = anchors[CORNER_R] - anchors[CORNER_L]
    horizontal = _normalized(horizontal) or Vector((1.0, 0.0, 0.0))

    vertical = anchors[TOP_C] - anchors[BOT_C]
    vertical = vertical - (horizontal * vertical.dot(horizontal))
    vertical = _normalized(vertical) or Vector((0.0, 0.0, 1.0))

    forward = _normalized(horizontal.cross(vertical)) or Vector((0.0, -1.0, 0.0))
    if normals:
        normal_sum = sum(normals.values(), Vector((0.0, 0.0, 0.0)))
        average_normal = _normalized(normal_sum)
        if average_normal is not None and forward.dot(average_normal) < 0.0:
            forward.negate()
    return horizontal, vertical, forward


def _set_childof_inverse(arm_obj, owner_bone_name, target_bone_name):
    """Bake a static ChildOf inverse so the constraint is a no-op at rest."""
    target_bone = arm_obj.data.bones.get(target_bone_name)
    pbone = arm_obj.pose.bones.get(owner_bone_name)
    if target_bone is None or pbone is None:
        return
    for con in pbone.constraints:
        if con.type == 'CHILD_OF' and con.subtarget == target_bone_name:
            con.inverse_matrix = target_bone.matrix_local.inverted()


def build_armature(
    anchor_positions,
    mesh_obj,
    normals=None,
    offset=0.0,
    head_origin=None,
    jaw_origin=None,
    jaw_control=None,
    bbone_segments=8,
    corner_jaw_follow=0.5,
    bottom_jaw_follow=1.0,
):
    """Create the MouthRig armature in the new 4-strand layout.

    anchor_positions: dict with TOP_C, BOT_C, CORNER_L, CORNER_R world positions.
    head_origin / jaw_origin / jaw_control: world Vectors for the deform roots.
    """
    if offset != 0.0 and normals:
        anchor_positions = {
            name: apply_surface_offset(pos, normals.get(name), offset)
            for name, pos in anchor_positions.items()
        }

    horizontal, vertical, forward = _compute_axes(anchor_positions, normals)
    lip_span = (anchor_positions[CORNER_R] - anchor_positions[CORNER_L]).length
    if lip_span < 1e-6:
        lip_span = 0.1

    alpha = lip_span * 0.04           # sub-CTRL offset
    master_length = lip_span * 0.15   # master CTRL forward length
    bone_width = max(lip_span * 0.01, 0.002)

    # Lip tangents at each corner (toward the upper / lower mid-arc point).
    # When the mid points aren't supplied (back-compat call without 8-point data),
    # fall back to pure vertical so the rig still builds, just with the old look.
    def _tangent(corner_key, mid_key, fallback):
        mid = anchor_positions.get(mid_key)
        if mid is None:
            return fallback
        delta = mid - anchor_positions[corner_key]
        return _normalized(delta) or fallback

    tangent_top_R = _tangent(CORNER_R, TOP_R_MID, vertical)
    tangent_top_L = _tangent(CORNER_L, TOP_L_MID, vertical)
    tangent_bot_R = _tangent(CORNER_R, BOT_R_MID, -vertical)
    tangent_bot_L = _tangent(CORNER_L, BOT_L_MID, -vertical)

    arm_name = f"MouthRig_{mesh_obj.name}"
    arm_data = bpy.data.armatures.new(f"{arm_name}_Data")
    arm_data.display_type = 'BBONE'
    arm_obj = bpy.data.objects.new(arm_name, arm_data)
    arm_obj.show_in_front = True
    arm_obj["mouthrig_owner_mesh"] = mesh_obj.name

    target_coll = mesh_obj.users_collection[0] if mesh_obj.users_collection else bpy.context.scene.collection
    target_coll.objects.link(arm_obj)

    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    arm_obj.select_set(True)
    bpy.context.view_layer.objects.active = arm_obj

    bpy.ops.object.mode_set(mode='EDIT')
    ebones = arm_data.edit_bones

    # ---- Head bone (root deform) ----
    if head_origin is None:
        # Fallback: place above the mouth centroid.
        centroid = sum(anchor_positions.values(), Vector((0.0, 0.0, 0.0))) / 4.0
        head_origin = centroid + (vertical * lip_span * 1.5)
    head_bone = ebones.new(HEAD_BONE_NAME)
    head_bone.head = head_origin.copy()
    head_bone.tail = head_origin + (vertical * lip_span * 0.5)
    head_bone.bbone_x = bone_width
    head_bone.bbone_z = bone_width

    # ---- Jaw bone ----
    jaw_bone = None
    if jaw_origin is not None and jaw_control is not None:
        jaw_bone = ebones.new(JAW_BONE_NAME)
        jaw_bone.head = jaw_origin.copy()
        jaw_tail = jaw_control.copy()
        if (jaw_tail - jaw_origin).length_squared < 1e-10:
            jaw_tail = jaw_origin + (vertical * -lip_span * 0.5)
        jaw_bone.tail = jaw_tail
        jaw_bone.bbone_x = bone_width
        jaw_bone.bbone_z = bone_width
        jaw_bone.parent = head_bone

    # ---- Master CTRL bones (parented to Head) ----
    def _make_master(name, head_pos):
        b = ebones.new(name)
        b.head = head_pos.copy()
        b.tail = head_pos + (forward * master_length)
        b.bbone_x = bone_width
        b.bbone_z = bone_width
        b.parent = head_bone
        b.use_deform = False
        return b

    master_top = _make_master(MOUTH_CENTER_TOP_CTRL, anchor_positions[TOP_C])
    master_bot = _make_master(MOUTH_CENTER_BOTTOM_CTRL, anchor_positions[BOT_C])
    master_corner_r = _make_master(CORNER_CTRL_R, anchor_positions[CORNER_R])
    master_corner_l = _make_master(CORNER_CTRL_L, anchor_positions[CORNER_L])

    # ---- Sub CTRLs at the centers ----
    horizontal_to_r = horizontal.copy()
    horizontal_to_l = -horizontal

    def _make_center_sub(name, anchor, side_dir, parent):
        b = ebones.new(name)
        b.head = anchor + (side_dir * alpha)
        b.tail = anchor.copy()
        b.bbone_x = bone_width
        b.bbone_z = bone_width
        b.parent = parent
        b.use_deform = False
        return b

    sub_top_r = _make_center_sub(CENTER_TOP_CTRL_R, anchor_positions[TOP_C], horizontal_to_r, master_top)
    sub_top_l = _make_center_sub(CENTER_TOP_CTRL_L, anchor_positions[TOP_C], horizontal_to_l, master_top)
    sub_bot_r = _make_center_sub(CENTER_BOTTOM_CTRL_R, anchor_positions[BOT_C], horizontal_to_r, master_bot)
    sub_bot_l = _make_center_sub(CENTER_BOTTOM_CTRL_L, anchor_positions[BOT_C], horizontal_to_l, master_bot)

    # ---- Sub CTRLs at the corners + DEF strand heads ----
    # tangent_dir = lip tangent at the corner pointing toward the upper/lower mid.
    # The sub-CTRL is laid along this tangent so its Y axis acts as the bbone
    # start handle direction; the strand then bends along the actual lip arc
    # at rest instead of cutting a straight chord through the air.
    def _make_corner_sub(name, corner_pos, tangent_dir, master, def_name, def_tail_anchor):
        # DEF head sits slightly along the lip tangent from the corner.
        def_head = corner_pos + (tangent_dir * (alpha * 0.3))
        # Sub CTRL is positioned along the same tangent. Head is "back" of the
        # corner (graspable), tail meets the DEF head, so Y axis = +tangent_dir.
        b = ebones.new(name)
        b.head = corner_pos - (tangent_dir * (alpha * 0.7))
        b.tail = def_head
        b.bbone_x = bone_width
        b.bbone_z = bone_width
        b.parent = master
        b.use_deform = False

        d = ebones.new(def_name)
        d.head = def_head
        d.tail = def_tail_anchor.copy()
        d.bbone_segments = bbone_segments
        d.bbone_x = bone_width
        d.bbone_z = bone_width
        d.parent = b
        d.use_connect = True
        d.use_deform = True
        d.bbone_handle_type_start = 'ABSOLUTE'
        d.bbone_handle_type_end = 'ABSOLUTE'
        return b, d

    # DEF tails sit slightly off-center on the horizontal axis so the L and R
    # strands don't collide at top_C / bot_C. Mirrors the head-offset trick.
    tail_offset = alpha * 0.5
    top_tail_r = anchor_positions[TOP_C] + (horizontal_to_r * tail_offset)
    top_tail_l = anchor_positions[TOP_C] + (horizontal_to_l * tail_offset)
    bot_tail_r = anchor_positions[BOT_C] + (horizontal_to_r * tail_offset)
    bot_tail_l = anchor_positions[BOT_C] + (horizontal_to_l * tail_offset)

    _corner_top_r, def_top_r = _make_corner_sub(
        CORNER_TOP_CTRL_R, anchor_positions[CORNER_R], tangent_top_R, master_corner_r,
        DEF_TOP_R, top_tail_r,
    )
    _corner_top_l, def_top_l = _make_corner_sub(
        CORNER_TOP_CTRL_L, anchor_positions[CORNER_L], tangent_top_L, master_corner_l,
        DEF_TOP_L, top_tail_l,
    )
    _corner_bot_r, def_bot_r = _make_corner_sub(
        CORNER_BOTTOM_CTRL_R, anchor_positions[CORNER_R], tangent_bot_R, master_corner_r,
        DEF_BOTTOM_R, bot_tail_r,
    )
    _corner_bot_l, def_bot_l = _make_corner_sub(
        CORNER_BOTTOM_CTRL_L, anchor_positions[CORNER_L], tangent_bot_L, master_corner_l,
        DEF_BOTTOM_L, bot_tail_l,
    )

    # Align roll on every mouth bone so its local Z points outward (forward).
    # Without this the bbone segments spiral as the bone direction sweeps through
    # different angles around the mouth ring.
    mouth_roll_bones = (
        master_top, master_bot, master_corner_r, master_corner_l,
        sub_top_r, sub_top_l, sub_bot_r, sub_bot_l,
        _corner_top_r, _corner_top_l, _corner_bot_r, _corner_bot_l,
        def_top_r, def_top_l, def_bot_r, def_bot_l,
    )
    for ebone in mouth_roll_bones:
        ebone.align_roll(forward)

    bpy.ops.object.mode_set(mode='OBJECT')

    # ---- BBone custom handles (ABSOLUTE start = corner sub, end = center sub) ----
    _DEF_HANDLES = (
        (DEF_TOP_R,    CORNER_TOP_CTRL_R,    CENTER_TOP_CTRL_R),
        (DEF_TOP_L,    CORNER_TOP_CTRL_L,    CENTER_TOP_CTRL_L),
        (DEF_BOTTOM_R, CORNER_BOTTOM_CTRL_R, CENTER_BOTTOM_CTRL_R),
        (DEF_BOTTOM_L, CORNER_BOTTOM_CTRL_L, CENTER_BOTTOM_CTRL_L),
    )
    for def_name, start_name, end_name in _DEF_HANDLES:
        bone = arm_data.bones.get(def_name)
        start_bone = arm_data.bones.get(start_name)
        end_bone = arm_data.bones.get(end_name)
        if bone is None or start_bone is None or end_bone is None:
            continue
        bone.bbone_handle_type_start = 'ABSOLUTE'
        bone.bbone_handle_type_end = 'ABSOLUTE'
        bone.bbone_custom_handle_start = start_bone
        bone.bbone_custom_handle_end = end_bone

    # ---- Pose-mode constraints ----
    bpy.ops.object.mode_set(mode='POSE')

    def _add_stretch_to(owner_name, target_name):
        pbone = arm_obj.pose.bones.get(owner_name)
        if pbone is None:
            return
        con = pbone.constraints.new('STRETCH_TO')
        con.name = "Stretch To"
        con.target = arm_obj
        con.subtarget = target_name
        con.influence = 1.0

    _add_stretch_to(DEF_TOP_R, CENTER_TOP_CTRL_R)
    _add_stretch_to(DEF_TOP_L, CENTER_TOP_CTRL_L)
    _add_stretch_to(DEF_BOTTOM_R, CENTER_BOTTOM_CTRL_R)
    _add_stretch_to(DEF_BOTTOM_L, CENTER_BOTTOM_CTRL_L)

    if jaw_bone is not None:
        def _add_child_of(owner_name, influence):
            pbone = arm_obj.pose.bones.get(owner_name)
            if pbone is None:
                return
            con = pbone.constraints.new('CHILD_OF')
            con.name = "Child Of"
            con.target = arm_obj
            con.subtarget = JAW_BONE_NAME
            con.influence = influence

        _add_child_of(MOUTH_CENTER_BOTTOM_CTRL, bottom_jaw_follow)
        _add_child_of(CORNER_CTRL_R, corner_jaw_follow)
        _add_child_of(CORNER_CTRL_L, corner_jaw_follow)

    bpy.ops.object.mode_set(mode='OBJECT')

    if jaw_bone is not None:
        for owner in (MOUTH_CENTER_BOTTOM_CTRL, CORNER_CTRL_R, CORNER_CTRL_L):
            _set_childof_inverse(arm_obj, owner, JAW_BONE_NAME)

    return arm_obj
