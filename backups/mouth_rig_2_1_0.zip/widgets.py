import bpy
import math
from mathutils import Vector, Quaternion
from .rig_builder import apply_surface_offset, ANCHOR_NAMES

_PREVIEW_COLL = "PREVIEW_MouthRig"
_PREVIEW_OFFSET_KEY = "mouthrig_preview_display_offset"

HEAD_EMPTY_NAME = "MouthRig_Head_Origin"
JAW_EMPTY_NAME = "MouthRig_Jaw_Origin"
JAW_CONTROL_EMPTY_NAME = "MouthRig_Jaw_Control_Chin"

PLACEMENT_EMPTY_NAMES = (HEAD_EMPTY_NAME, JAW_EMPTY_NAME, JAW_CONTROL_EMPTY_NAME)


# ---------------------------------------------------------------------------
# Collection helpers
# ---------------------------------------------------------------------------

def _get_or_create_collection(name):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(coll)
        coll.hide_render = True
    return coll


def _make_circle_mesh(name, radius, segments=16):
    verts = []
    edges = []
    for i in range(segments):
        angle = (math.tau * i) / segments
        verts.append((math.cos(angle) * radius, 0.0, math.sin(angle) * radius))
        edges.append((i, (i + 1) % segments))

    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, edges, [])
    mesh.update()
    return mesh


# ---------------------------------------------------------------------------
# Preview data persistence
# ---------------------------------------------------------------------------

def save_preview_data(scene, positions, normals):
    data = {}
    for name, pos in positions.items():
        n = normals.get(name, Vector((0.0, 1.0, 0.0)))
        data[name] = [pos.x, pos.y, pos.z, n.x, n.y, n.z]
    scene["mouthrig_preview_data"] = data


def load_preview_data(scene):
    raw = scene.get("mouthrig_preview_data")
    if not raw:
        return None, None
    positions = {}
    normals = {}
    for name in raw.keys():
        vals = list(raw[name])
        positions[name] = Vector(vals[:3])
        normals[name] = Vector(vals[3:])
    return positions, normals


def save_rotations(scene, rotations):
    scene["mouthrig_preview_rotations"] = {
        name: [q.w, q.x, q.y, q.z] for name, q in rotations.items()
    }


def load_rotations(scene):
    raw = scene.get("mouthrig_preview_rotations")
    if not raw:
        return {}
    return {name: Quaternion(list(raw[name])) for name in raw.keys()}


def sync_rotations_from_viewport(scene):
    coll = bpy.data.collections.get(_PREVIEW_COLL)
    if not coll:
        return
    rots = load_rotations(scene)
    for obj in coll.objects:
        if not obj.name.startswith("PREVIEW_"):
            continue
        ctrl_name = obj.name[len("PREVIEW_"):]
        if obj.rotation_mode == 'QUATERNION':
            rots[ctrl_name] = obj.rotation_quaternion.copy()
        else:
            rots[ctrl_name] = obj.rotation_euler.to_quaternion()
    save_rotations(scene, rots)


def sync_preview_positions_from_viewport(scene):
    positions, normals = load_preview_data(scene)
    if positions is None:
        return None, None

    coll = bpy.data.collections.get(_PREVIEW_COLL)
    if not coll:
        return positions, normals

    # Use the offset that produced the objects currently in the viewport. The
    # Scene property may already contain a newly entered value while its update
    # callback is running.
    offset = float(scene.get(_PREVIEW_OFFSET_KEY, 0.0))
    for obj in coll.objects:
        if not obj.name.startswith("PREVIEW_"):
            continue
        ctrl_name = obj.name[len("PREVIEW_"):]
        if ctrl_name not in positions:
            continue
        displayed_pos = obj.location.copy()
        n_vec = normals.get(ctrl_name)
        if n_vec is not None and offset != 0.0:
            displayed_pos = apply_surface_offset(displayed_pos, n_vec, -offset)
        positions[ctrl_name] = displayed_pos

    save_preview_data(scene, positions, normals)
    return positions, normals


def save_preview_mesh(scene, mesh_obj):
    scene["mouthrig_preview_mesh"] = mesh_obj.name


def load_preview_mesh(scene):
    mesh_name = scene.get("mouthrig_preview_mesh")
    return bpy.data.objects.get(mesh_name) if mesh_name else None


# ---------------------------------------------------------------------------
# Placement empties (Head origin, Jaw origin, Jaw control)
# ---------------------------------------------------------------------------

def _placement_defaults(anchor_positions):
    left = anchor_positions.get("corner_L")
    right = anchor_positions.get("corner_R")
    top = anchor_positions.get("top_C")
    bottom = anchor_positions.get("bot_C")

    if all(p is not None for p in (left, right, top, bottom)):
        center = (left + right) / 2.0
        up = top - bottom
        if up.length_squared < 1e-10:
            up = Vector((0.0, 0.0, 1.0))
        up.normalize()
        lip_span = max((right - left).length, 0.1)
        down = -up
        return {
            HEAD_EMPTY_NAME: center + (up * lip_span * 1.5),
            JAW_EMPTY_NAME: center + (down * lip_span * 0.35),
            JAW_CONTROL_EMPTY_NAME: bottom + (down * lip_span * 0.5),
        }

    return {
        HEAD_EMPTY_NAME: Vector((0.0, 0.0, 1.0)),
        JAW_EMPTY_NAME: Vector((0.0, 0.0, 0.0)),
        JAW_CONTROL_EMPTY_NAME: Vector((0.0, 0.0, -0.1)),
    }


def _create_or_update_placement_empty(name, location, display_type, display_size):
    coll = _get_or_create_collection(_PREVIEW_COLL)
    existing = bpy.data.objects.get(name)
    if existing:
        if existing.name not in coll.objects.keys():
            for user_coll in list(existing.users_collection):
                user_coll.objects.unlink(existing)
            coll.objects.link(existing)
        if location is not None:
            existing.location = location
        existing.empty_display_type = display_type
        existing.empty_display_size = display_size
        existing.show_name = True
        existing.show_in_front = True
        return existing

    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = display_type
    empty.empty_display_size = display_size
    empty.show_name = True
    empty.show_in_front = True
    empty.location = location.copy()
    coll.objects.link(empty)
    return empty


def create_placement_empties(anchor_positions, locations=None, control_size=0.05):
    """Create or preserve named placement empties for head, jaw, and jaw-control."""
    defaults = _placement_defaults(anchor_positions)
    locations = locations or {}
    _create_or_update_placement_empty(
        HEAD_EMPTY_NAME,
        locations.get(HEAD_EMPTY_NAME, defaults[HEAD_EMPTY_NAME]),
        'SPHERE',
        max(control_size * 1.5, 0.01),
    )
    _create_or_update_placement_empty(
        JAW_EMPTY_NAME,
        locations.get(JAW_EMPTY_NAME, defaults[JAW_EMPTY_NAME]),
        'SPHERE',
        max(control_size * 1.5, 0.01),
    )
    _create_or_update_placement_empty(
        JAW_CONTROL_EMPTY_NAME,
        locations.get(JAW_CONTROL_EMPTY_NAME, defaults[JAW_CONTROL_EMPTY_NAME]),
        'CIRCLE',
        max(control_size * 2.0, 0.015),
    )


def _get_empty_location(name):
    empty = bpy.data.objects.get(name)
    return empty.location.copy() if empty else None


def get_placement_locations():
    return {
        name: loc
        for name in PLACEMENT_EMPTY_NAMES
        if (loc := _get_empty_location(name)) is not None
    }


def get_head_origin_location():
    return _get_empty_location(HEAD_EMPTY_NAME)


def get_jaw_empty_location():
    return _get_empty_location(JAW_EMPTY_NAME)


def get_jaw_control_location():
    return _get_empty_location(JAW_CONTROL_EMPTY_NAME)


# ---------------------------------------------------------------------------
# Anchor preview circles
# ---------------------------------------------------------------------------

def create_preview_widgets(anchor_positions, radius=0.05, normals=None,
                           rotations=None, offset=0.0):
    """Place visible circle objects at the 4 main anchor positions.

    Mid-arc points are stored in `anchor_positions` for the builder but are not
    drawn as preview circles; they are computed from the loop and used only for
    tangent orientation of the corner sub-CTRLs.
    """
    placement_locations = get_placement_locations()
    clear_preview_widgets()
    coll = _get_or_create_collection(_PREVIEW_COLL)

    visible_positions = {
        name: pos for name, pos in anchor_positions.items() if name in ANCHOR_NAMES
    }

    for name, pos in visible_positions.items():
        obj_name = f"PREVIEW_{name}"
        final_pos = pos.copy()

        n_vec = normals.get(name) if normals else None
        if n_vec and offset != 0.0:
            final_pos = apply_surface_offset(final_pos, n_vec, offset)

        mesh = _make_circle_mesh(obj_name, radius)
        obj = bpy.data.objects.new(obj_name, mesh)
        obj.location = final_pos
        obj.show_in_front = True
        obj.display_type = 'WIRE'
        obj["mouthrig_preview_anchor"] = name

        rot = rotations.get(name) if rotations else None
        if rot:
            obj.rotation_mode = 'QUATERNION'
            obj.rotation_quaternion = rot

        coll.objects.link(obj)

    create_placement_empties(anchor_positions, locations=placement_locations, control_size=radius)
    bpy.context.scene[_PREVIEW_OFFSET_KEY] = float(offset)


def clear_preview_widgets():
    """Remove all preview anchor objects, placement empties, and the collection."""
    coll = bpy.data.collections.get(_PREVIEW_COLL)
    if not coll:
        return
    for obj in list(coll.objects):
        mesh_data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh_data and getattr(mesh_data, "users", 0) == 0:
            bpy.data.meshes.remove(mesh_data)
    bpy.data.collections.remove(coll)


def clear_preview_state(scene):
    """Clear persisted preview metadata after Build or Clear."""
    for key in (
        "mouthrig_preview_data",
        "mouthrig_preview_rotations",
        "mouthrig_preview_mesh",
        _PREVIEW_OFFSET_KEY,
    ):
        if key in scene:
            del scene[key]
