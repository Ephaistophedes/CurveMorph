bl_info = {
    "name": "Mouth Rig Builder",
    "author": "",
    "version": (2, 1, 0),
    "blender": (5, 0, 0),
    "location": "View3D > N-Panel > Mouth Rig",
    "description": "Builds a 4-strand bendy-bone mouth rig from a selected mouth edge loop",
    "category": "Rigging",
}

import bpy
from mathutils import Vector
from . import rig_builder, widgets, operators, ui


def _on_align_changed(self, context):
    scene = context.scene
    positions, normals = widgets.load_preview_data(scene)
    if positions is None:
        return

    # Capture hand-edited anchor positions before recreating preview objects.
    positions, normals = widgets.sync_preview_positions_from_viewport(scene)
    widgets.sync_rotations_from_viewport(scene)

    if scene.mouthrig_align_to_normal:
        y_axis = Vector((0.0, 1.0, 0.0))
        rotations = {
            name: y_axis.rotation_difference(normals[name].normalized())
            for name in normals
        }
    else:
        rotations = {}
    widgets.save_rotations(scene, rotations)

    widgets.create_preview_widgets(
        positions,
        radius=scene.mouthrig_widget_radius,
        normals=normals,
        rotations=rotations or None,
        offset=scene.mouthrig_surface_offset,
    )


def _on_size_offset_changed(self, context):
    scene = context.scene
    positions, normals = widgets.load_preview_data(scene)
    if positions is None:
        return

    positions, normals = widgets.sync_preview_positions_from_viewport(scene)
    widgets.sync_rotations_from_viewport(scene)
    rotations = widgets.load_rotations(scene)
    widgets.create_preview_widgets(
        positions,
        radius=scene.mouthrig_widget_radius,
        normals=normals,
        rotations=rotations or None,
        offset=scene.mouthrig_surface_offset,
    )


def _on_bone_visibility_changed(self, context):
    operators.apply_bone_visibility(context)


_PROP_NAMES = (
    "mouthrig_widget_radius",
    "mouthrig_align_to_normal",
    "mouthrig_surface_offset",
    "mouthrig_bbone_segments",
    "mouthrig_corner_jaw_follow",
    "mouthrig_bottom_jaw_follow",
    "mouthrig_show_def_bones",
    "mouthrig_show_ctrl_bones",
    "mouthrig_show_jaw_bone",
    "mouthrig_show_head_bone",
)


def register():
    bpy.types.Scene.mouthrig_widget_radius = bpy.props.FloatProperty(
        name="Control Size",
        description="Radius of the preview anchor circles",
        default=0.05,
        min=0.001,
        max=0.5,
        precision=3,
        subtype='DISTANCE',
        update=_on_size_offset_changed,
    )
    bpy.types.Scene.mouthrig_align_to_normal = bpy.props.BoolProperty(
        name="Align Preview to Normals",
        description="Orient preview circles along the detected mesh surface normals",
        default=False,
        update=_on_align_changed,
    )
    bpy.types.Scene.mouthrig_surface_offset = bpy.props.FloatProperty(
        name="Surface Offset",
        description="Push anchors outward from the mesh surface along the vertex normal",
        default=0.0,
        min=-0.5,
        max=1.0,
        precision=3,
        subtype='DISTANCE',
        update=_on_size_offset_changed,
    )
    bpy.types.Scene.mouthrig_bbone_segments = bpy.props.IntProperty(
        name="Bbone Segments",
        description="Number of bendy-bone segments per DEF lip strand",
        default=8,
        min=1,
        max=32,
    )
    bpy.types.Scene.mouthrig_corner_jaw_follow = bpy.props.FloatProperty(
        name="Corner Jaw Follow",
        description="Influence of Jaw on Corner_CTRL_L/R via Child Of constraint",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
    )
    bpy.types.Scene.mouthrig_bottom_jaw_follow = bpy.props.FloatProperty(
        name="Bottom Jaw Follow",
        description="Influence of Jaw on Mouth_Center_Bottom_CTRL via Child Of constraint",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=3,
    )
    bpy.types.Scene.mouthrig_show_def_bones = bpy.props.BoolProperty(
        name="DEF Strands",
        description="Show or hide the 4 DEF_* bendy strands",
        default=True,
        update=_on_bone_visibility_changed,
    )
    bpy.types.Scene.mouthrig_show_ctrl_bones = bpy.props.BoolProperty(
        name="CTRL Bones",
        description="Show or hide the master and sub control bones",
        default=True,
        update=_on_bone_visibility_changed,
    )
    bpy.types.Scene.mouthrig_show_jaw_bone = bpy.props.BoolProperty(
        name="Jaw",
        description="Show or hide the Jaw bone",
        default=True,
        update=_on_bone_visibility_changed,
    )
    bpy.types.Scene.mouthrig_show_head_bone = bpy.props.BoolProperty(
        name="Head",
        description="Show or hide the Head root bone",
        default=False,
        update=_on_bone_visibility_changed,
    )
    operators.register()
    ui.register()


def unregister():
    ui.unregister()
    operators.unregister()
    for prop in _PROP_NAMES:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
