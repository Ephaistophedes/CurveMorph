# Mouth Rig Builder

A Blender 5 legacy add-on that creates a four-strand bendy-bone mouth rig from a selected mouth edge loop.

## Install

1. Keep this entire `mouth_rig_addon` directory together.
2. Place it in Blender's user `scripts/addons` directory, or install a ZIP whose top-level folder is `mouth_rig_addon`.
3. Enable **Mouth Rig Builder** in Blender Preferences.
4. Open the 3D Viewport sidebar and select the **Mouth Rig** tab.

## Workflow

1. Select an unrigged mesh and enter Edit Mode.
2. Select one connected, closed mouth edge loop with at least 8 vertices.
3. Click **Display Controls**.
4. In Object Mode, move the four anchor circles and the Head, Jaw, and Chin placement empties.
5. Optionally select one corner circle and click **Mirror Selected Corner**.
6. Adjust the rig settings and click **Generate Mouth Rig**.
7. Refine Blender's automatic weights with Weight Paint as needed.

## Safety Checks

- Build stops instead of replacing another Armature modifier or armature parent.
- Existing `Head`, `Jaw`, or `DEF_*` vertex groups are never overwritten silently.
- A failed build removes its partial armature and generated groups while preserving the preview for another attempt.
- **Clear Mouth Rig** only removes data tied to the resolved Mouth Rig target.

## Troubleshooting

- If **Display Controls** is disabled, activate a mesh, enter Edit Mode, and select the loop.
- If loop detection fails, ensure the selection is closed, connected, unbranched, and contains at least 8 vertices.
- If automatic weighting fails, apply mesh scale, remove non-manifold geometry near the mouth, and try again.
- The add-on intentionally refuses meshes already driven by another armature. Use a duplicate mesh until multi-armature integration is explicitly supported.
