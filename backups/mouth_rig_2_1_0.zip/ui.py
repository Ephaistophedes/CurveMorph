import bpy
from . import widgets


def _active_rig_exists(context, preview_mesh):
    obj = context.active_object
    if obj is not None and obj.type == 'ARMATURE' and obj.get("mouthrig_owner_mesh"):
        return True
    if obj is not None and obj.type == 'MESH' and obj.get("mouthrig_armature_name"):
        return True
    return bool(preview_mesh and preview_mesh.get("mouthrig_armature_name"))


def _has_foreign_armature(mesh_obj):
    if mesh_obj is None or mesh_obj.type != 'MESH':
        return False
    stored_arm_name = mesh_obj.get("mouthrig_armature_name")
    return any(
        mod.type == 'ARMATURE'
        and (
            mod.object is None
            or (
                mod.object.name != stored_arm_name
                and mod.object.get("mouthrig_owner_mesh") != mesh_obj.name
            )
        )
        for mod in mesh_obj.modifiers
    )


class MOUTHRIG_PT_main(bpy.types.Panel):
    bl_label = "Mouth Rig Builder"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Mouth Rig"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        active = context.active_object
        preview_mesh = widgets.load_preview_mesh(scene)
        preview_positions, _preview_normals = widgets.load_preview_data(scene)
        preview_ready = preview_mesh is not None and preview_positions is not None
        rig_ready = _active_rig_exists(context, preview_mesh)

        setup = layout.box()
        setup.label(text="1. Detect Mouth Loop", icon='MESH_DATA')
        if preview_ready:
            setup.label(text=f"Preview ready: {preview_mesh.name}", icon='CHECKMARK')
        elif active is not None and active.type == 'MESH' and context.mode == 'EDIT_MESH':
            setup.label(text="Select one closed loop with 8+ vertices.", icon='INFO')
        else:
            setup.label(text="Select a mesh and enter Edit Mode.", icon='INFO')
        setup.operator("mouthrig.preview", text="Display Controls", icon='HIDE_OFF')

        preview = layout.box()
        preview.enabled = preview_ready
        preview.label(text="2. Place Controls", icon='EMPTY_ARROWS')
        preview.label(text="Move 4 circles and the 3 named empties.")
        preview.prop(scene, "mouthrig_widget_radius")
        preview.prop(scene, "mouthrig_align_to_normal")
        preview.prop(scene, "mouthrig_surface_offset")
        preview.operator("mouthrig.symmetrize", text="Mirror Selected Corner", icon='MOD_MIRROR')

        settings = layout.box()
        settings.label(text="3. Rig Settings", icon='BONE_DATA')
        settings.prop(scene, "mouthrig_bbone_segments")
        settings.prop(scene, "mouthrig_corner_jaw_follow")
        settings.prop(scene, "mouthrig_bottom_jaw_follow")

        build = layout.box()
        build.label(text="4. Generate", icon='OUTLINER_OB_ARMATURE')
        if _has_foreign_armature(preview_mesh):
            build.label(text="Another armature is attached to this mesh.", icon='ERROR')
            build.label(text="Duplicate or detach it before generating.")
        row = build.row()
        row.enabled = preview_ready and not _has_foreign_armature(preview_mesh)
        row.operator("mouthrig.build", text="Generate Mouth Rig", icon='OUTLINER_OB_ARMATURE')

        visibility = layout.box()
        visibility.enabled = rig_ready
        visibility.label(text="Bone Visibility", icon='HIDE_OFF')
        visibility.prop(scene, "mouthrig_show_def_bones")
        visibility.prop(scene, "mouthrig_show_ctrl_bones")
        visibility.prop(scene, "mouthrig_show_jaw_bone")
        visibility.prop(scene, "mouthrig_show_head_bone")
        visibility.operator("mouthrig.apply_visibility", icon='FILE_REFRESH')

        row = layout.row()
        row.enabled = preview_ready or rig_ready
        clear_text = "Cancel Preview" if preview_ready and not rig_ready else "Clear Mouth Rig"
        row.operator("mouthrig.clear", text=clear_text, icon='TRASH')


_classes = (MOUTHRIG_PT_main,)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
